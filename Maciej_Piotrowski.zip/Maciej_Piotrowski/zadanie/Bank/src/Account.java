import java.util.Scanner;

public class Account {
    private String street;
    private int money;
    private String surnameAccount;
    private String dateOfBirth;
    protected int age;
    private String nameAccount;
    private String pesel;

    public Account(String street, int numberOfHome, String surnameAccount, String dateOfBirth, int age, String nameAccount, String pesel) {
        this.street = street;
        this.money = money;
        this.surnameAccount = surnameAccount;
        this.dateOfBirth = dateOfBirth;
        this.age = age;
        this.nameAccount = nameAccount;
        this.pesel = pesel;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public String getSurnameAccount() {
        return surnameAccount;
    }

    public void setSurnameAccount(String surnameAccount) {
        this.surnameAccount = surnameAccount;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getNameAccount() {
        return nameAccount;
    }

    public void setNameAccount(String nameAccount) {
        this.nameAccount = nameAccount;
    }

    public String getPesel() {
        return pesel;
    }

    public void setPesel(String pesel) {
        this.pesel = pesel;
    }
    /*********************************************************
     * nazwa funkcji: <SHOWINFORMATION>*
     * parametry wejściowe: BRAK*
     * wartość zwracana: *BRAK *
     * autor: <Maciej Piotrowski>*
     * ****************************************************/
    private void showInformation(){
        System.out.println(this.street);
        System.out.println(this.money);
        System.out.println(this.surnameAccount);
        System.out.println(this.dateOfBirth);
        System.out.println(this.age);
        System.out.println(this.nameAccount);
        System.out.println(this.pesel);
    }
    /*********************************************************
     * nazwa funkcji: <PAYMENT>*
     * parametry wejściowe: BRAK*
     * wartość zwracana: * money*
     * autor: <Maciej Piotrowski>*
     * ****************************************************/
    private int payment(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Ile hajsu chcesz wpłacić");
        int addMoney = scan.nextInt();
        return this.money += addMoney;
    }
    /*********************************************************
     * nazwa funkcji: <PAYCHECK>*
     * parametry wejściowe: BRAK*
     * wartość zwracana: * money*
     * autor: <Maciej Piotrowski>*
     * ****************************************************/
    private int paycheck() {
        Scanner scan = new Scanner(System.in);
        System.out.println("Ile hajsu chcesz wypłacić");
        int minusMoney = scan.nextInt();
        return this.money -= minusMoney;
    }
    /*********************************************************
     * nazwa funkcji: <choice>*
     * parametry wejściowe: BRAK*
     * wartość zwracana: * BRAK*
     * autor: <Maciej Piotrowski>*
     * ****************************************************/
    public void choice(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Wybierz opcje 1/2/3:");
        System.out.println("1 - Pokaż dane ");
        System.out.println("2 - Wpłać");
        System.out.println("3 - Wypłać");
        int choice = scan.nextInt();
        if(choice ==1){
            showInformation();
        }
        else if(choice == 2){
            payment();
        }
        else if(choice == 3){
            paycheck();
        }
        else{
            System.out.println("Coś poszło nie tak");
        }

    }
}
