//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Bank bank = new Bank("Morska 11",1000, "Kamil-Piotr","Janowski",100,"Jax","Hokeista");
        Bank bank1 = new Bank("Morska 11",1000, "Kamil-Piotr","Janowski",100,"Jax","Hokeista");
        Bank bank2 = new Bank("Morska 11",1000, "Kamil-Piotr","Janowski",100,"Jax","Hokeista");
        bank.choice();
        Account account = new Account("Wiktora LOL",2000,"Janowski","2005-03-10",18,"Kamil","05100312323");
        Account account1 = new Account("Wiktora LOL",2000,"Janowski","2005-03-10",18,"Kamil","05100312323");
        Account account2 = new Account("Wiktora LOL",2000,"Janowski","2005-03-10",18,"Kamil","05100312323");
        account.choice();
        Admin admin = new Admin("Romana Giertycha",11,"Admin","Admin","11-11-2001",22,"2137604201");
        Admin admin1 = new Admin("Romana Giertycha",11,"Admin","Admin","11-11-2001",22,"2137604201");
        Admin admin2 = new Admin("Romana Giertycha",11,"Admin","Admin","11-11-2001",22,"2137604201");
        admin.choice();
    }
}