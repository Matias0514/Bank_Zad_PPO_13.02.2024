import java.util.Scanner;

public class Bank {
    public String addressHeadquarters;
    protected int numberOfAccounts;
    protected String namePresident;
    private String surnamePresident;
    protected int numberOfEmployees;
    protected String nameVicePresident;
    private String surnameVicePresident;

    public String getAddressHeadquarters() {
        return addressHeadquarters;
    }

    public void setAddressHeadquarters(String addressHeadquarters) {
        this.addressHeadquarters = addressHeadquarters;
    }

    public int getNumberOfAccounts() {
        return numberOfAccounts;
    }

    public void setNumberOfAccounts(int numberOfAccounts) {
        this.numberOfAccounts = numberOfAccounts;
    }

    public String getNamePresident() {
        return namePresident;
    }

    public void setNamePresident(String namePresident) {
        this.namePresident = namePresident;
    }

    public String getSurnamePresident() {
        return surnamePresident;
    }

    public void setSurnamePresident(String surnamePresident) {
        this.surnamePresident = surnamePresident;
    }

    public int getNumberOfEmployees() {
        return numberOfEmployees;
    }

    public void setNumberOfEmployees(int numberOfEmployees) {
        this.numberOfEmployees = numberOfEmployees;
    }

    public String getNameVicePresident() {
        return nameVicePresident;
    }

    public void setNameVicePresident(String nameVicePresident) {
        this.nameVicePresident = nameVicePresident;
    }

    public String getSurnameVicePresident() {
        return surnameVicePresident;
    }

    public void setSurnameVicePresident(String surnameVicePresident) {
        this.surnameVicePresident = surnameVicePresident;
    }

    public Bank(String addressHeadquarters, int numberOfAccounts, String namePresident, String surnamePresident, int numberOfEmployees, String nameVicePresident, String surnameVicePresident) {
        this.addressHeadquarters = addressHeadquarters;
        this.numberOfAccounts = numberOfAccounts;
        this.namePresident = namePresident;
        this.surnamePresident = surnamePresident;
        this.numberOfEmployees = numberOfEmployees;
        this.nameVicePresident = nameVicePresident;
        this.surnameVicePresident = surnameVicePresident;
    }
    /*********************************************************
     * nazwa funkcji: <choice>*
     * parametry wejściowe: BRAK*
     * wartość zwracana: * BRAK*
     * autor: <Maciej Piotrowski>*
     * ****************************************************/
    protected void choice(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Wybierz opcje 1/2:");
        System.out.println("1 - Pokaż dane prezesa");
        System.out.println("2 - Zatrudnij pracownika");
        int wyborowa = scan.nextInt();
        if(wyborowa ==1){
            showInformationOfPresident();
        }
        else if(wyborowa == 2){
            hireAnEmployee();
        }
        else{
            System.out.println("Coś poszło nie tak");
        }
    }
    /*********************************************************
     * nazwa funkcji: <SHOWINFORMATIONOFPRESIDENT>*
     * parametry wejściowe: BRAK*
     * wartość zwracana: *BRAK *
     * autor: <Maciej Piotrowski>*
     * ****************************************************/
    private void showInformationOfPresident(){
        System.out.println("Name:" + this.namePresident + " Surname:" + this.surnamePresident);
    }
    /*********************************************************
     * nazwa funkcji: <HIREANEMPLOYEE>*
     * parametry wejściowe: BRAK*
     * wartość zwracana: *numberofEmployees *
     * autor: <Maciej Piotrowski>*
     * ****************************************************/
    private int hireAnEmployee(){
        System.out.println("Zatrudniono nowego pracownika");
        return numberOfEmployees += 1;
    }
}
