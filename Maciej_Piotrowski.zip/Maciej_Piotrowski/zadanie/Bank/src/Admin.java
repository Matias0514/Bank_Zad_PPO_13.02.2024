import java.util.Scanner;

public class Admin {
    private String street;
    private int numberOfHome;
    private String nameAccount;
    private String surnameAccount;
    private String dateOfBirth;
    protected int age;
    private String pesel;

    public Admin(String street, int numberOfHome, String nameAccount, String surnameAccount, String dateOfBirth, int age, String pesel) {
        this.street = street;
        this.numberOfHome = numberOfHome;
        this.nameAccount = nameAccount;
        this.surnameAccount = surnameAccount;
        this.dateOfBirth = dateOfBirth;
        this.age = age;
        this.pesel = pesel;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public int getNumberOfHome() {
        return numberOfHome;
    }

    public void setNumberOfHome(int numberOfHome) {
        this.numberOfHome = numberOfHome;
    }

    public String getNameAccount() {
        return nameAccount;
    }

    public void setNameAccount(String nameAccount) {
        this.nameAccount = nameAccount;
    }

    public String getSurnameAccount() {
        return surnameAccount;
    }

    public void setSurnameAccount(String surnameAccount) {
        this.surnameAccount = surnameAccount;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPesel() {
        return pesel;
    }

    public void setPesel(String pesel) {
        this.pesel = pesel;
    }
    /*********************************************************
     * nazwa funkcji: <SHOWINFORMATION>*
     * parametry wejściowe: BRAK*
     * wartość zwracana: *BRAK *
     * autor: <Maciej Piotrowski>*
     * ****************************************************/
    private void showInformation(){
        System.out.println(this.street);
        System.out.println(this.numberOfHome);
        System.out.println(this.surnameAccount);
        System.out.println(this.dateOfBirth);
        System.out.println(this.age);
        System.out.println(this.nameAccount);
        System.out.println(this.pesel);
    }
    /*********************************************************
     * nazwa funkcji: <CHANGEADDRESS>*
     * parametry wejściowe: BRAK*
     * wartość zwracana: *STREET *
     * autor: <Maciej Piotrowski>*
     * ****************************************************/
    private void changeAddress(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Podaj nową ulicę");
        this.street = scan.nextLine();
    }
    /*********************************************************
     * nazwa funkcji: <choice>*
     * parametry wejściowe: BRAK*
     * wartość zwracana: * BRAK*
     * autor: <Maciej Piotrowski>*
     * ****************************************************/
    protected void choice(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Wybierz opcje 1/2:");
        System.out.println("1 - Pokaż dane kierownika");
        System.out.println("2 - Zmień ulicę");
        int choice = scan.nextInt();
        if(choice ==1){
            showInformation();
        }
        else if(choice == 2){
            changeAddress();
        }
        else{
            System.out.println("Coś poszło nie tak");
        }
    }
}
